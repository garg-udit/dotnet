﻿using BooksMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BooksMVC.Controllers
{
    public class BookController : Controller
    {
        private readonly BooksDbContext _context;

        public BookController(BooksDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddBook(BookModel book)
        {
            if (ModelState.IsValid)
            {
                _context.tbl_books.Add(book);
                _context.SaveChanges();
                ViewBag.BookID = book.BookID; // Show the auto-generated BookID
                return View("BookAdded");
            }
            return View(book);
        }

        public IActionResult ShowBooks()
        {
            var books = _context.tbl_books.ToList();
            return View(books);
        }
    }
}
