﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BooksMVC.Models; // Ensure this namespace is correct
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BooksMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksApiController : ControllerBase
    {
        private readonly BooksDbContext _context;

        public BooksApiController(BooksDbContext context)
        {
            _context = context;
        }

        // GET: api/books
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookModel>>> GetBooks()
        {
            return await _context.tbl_books.ToListAsync();
        }
    }
}
