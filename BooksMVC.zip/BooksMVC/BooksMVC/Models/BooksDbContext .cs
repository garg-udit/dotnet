﻿using Microsoft.EntityFrameworkCore;

namespace BooksMVC.Models
{
    public class BooksDbContext : DbContext
    {
        public BooksDbContext(DbContextOptions<BooksDbContext> options) : base(options) { }

        public DbSet<BookModel> tbl_books { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BookModel>(entity =>
            {
                entity.Property(e => e.BookPrice)
                    .HasColumnType("decimal(18,2)"); // Specify the SQL Server column type
            });
        }
    }
}
