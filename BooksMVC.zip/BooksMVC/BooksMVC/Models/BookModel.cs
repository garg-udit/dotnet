﻿namespace BooksMVC.Models
{
    using System.ComponentModel.DataAnnotations;

    public class BookModel
    {
        [Key]
        public int BookID { get; set; }

        [Required(ErrorMessage = "Book Name is required")]
        public string BookName { get; set; }

        [Required(ErrorMessage = "Author Name is required")]
        public string BookAuthor { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Price must be a positive value")]
        public decimal BookPrice { get; set; }
    }

}
