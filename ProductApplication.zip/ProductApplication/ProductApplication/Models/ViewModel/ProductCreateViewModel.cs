﻿using System.ComponentModel.DataAnnotations;

namespace ProductApplication.Models.ViewModel
{
    public class ProductCreateViewModel
    {
        [Required]
        public string? Name { get; set; }

        [Range(0, 999999)]
        public decimal Price { get; set; }
    }

}
