﻿using System.ComponentModel.DataAnnotations;

public class ProductEditViewModel
{
    public int Id { get; set; }

    [Required]
    public string? Name { get; set; }

    [Range(0, 999999)]
    public decimal Price { get; set; }
}
