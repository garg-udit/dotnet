﻿using Microsoft.EntityFrameworkCore;
using ProductApplication.Models;
using System;

namespace ProductApplication.Data
{
    public class ApplicationDbContext  :  DbContext
    {

        public ApplicationDbContext(DbContextOptions <ApplicationDbContext> options) : base(options) { }
        public DbSet<Product> Products { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Sample Product 1", Price = 10.00m },
                new Product { Id = 2, Name = "Sample Product 2", Price = 20.00m },
                new Product { Id = 3, Name = "Sample Product 3", Price = 30.00m },
                new Product { Id = 4, Name = "Sample Product 4", Price = 40.00m },
                new Product { Id = 5, Name = "Sample Product 5", Price = 50.00m },
                new Product { Id = 6, Name = "Sample Product 6", Price = 60.00m },
                new Product { Id = 7, Name = "Sample Product 7", Price = 70.00m },
                new Product { Id = 8, Name = "Sample Product 8", Price = 80.00m },
                new Product { Id = 9, Name = "Sample Product 9", Price = 90.00m },
                new Product { Id = 10, Name = "Sample Product 10", Price = 100.00m },
                new Product { Id = 11, Name = "Sample Product 11", Price = 110.00m },
                new Product { Id = 12, Name = "Sample Product 12", Price = 120.00m },
                new Product { Id = 13, Name = "Sample Product 13", Price = 130.00m },
                new Product { Id = 14, Name = "Sample Product 14", Price = 140.00m },
                new Product { Id = 15, Name = "Sample Product 15", Price = 150.00m },
                new Product { Id = 16, Name = "Sample Product 16", Price = 160.00m },
                new Product { Id = 17, Name = "Sample Product 17", Price = 170.00m },
                new Product { Id = 18, Name = "Sample Product 18", Price = 180.00m },
                new Product { Id = 19, Name = "Sample Product 19", Price = 190.00m },
                new Product { Id = 20, Name = "Sample Product 20", Price = 200.00m }
            );
        }


    }
}
