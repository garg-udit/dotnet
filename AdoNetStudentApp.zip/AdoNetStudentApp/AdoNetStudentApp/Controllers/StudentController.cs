﻿using Microsoft.AspNetCore.Mvc;
using AdoNetStudentApp.Data;
using AdoNetStudentApp.Models;
namespace AdoNetStudentApp.Controllers
{


    public class StudentController : Controller
    {
        private readonly AdoStudentHelper _db;

        public StudentController(AdoStudentHelper db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            var students = _db.GetAllStudents();
            return View(students);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                _db.InsertStudent(student);
                return RedirectToAction("Index");
            }
            return View(student);
        }

        public IActionResult Edit(int id)
        {
            var student = _db.GetStudentById(id);
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(Student student)
        {
            _db.UpdateStudent(student);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var student = _db.GetStudentById(id);
            return View(student);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _db.DeleteStudent(id);
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var student = _db.GetStudentById(id);
            return View(student);
        }
    }

}
