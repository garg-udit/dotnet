﻿using Microsoft.Data.SqlClient;
using AdoNetStudentApp.Models;

namespace AdoNetStudentApp.Data
{
    public class AdoStudentHelper
    {
        private readonly string _connectionString;

        public AdoStudentHelper(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<Student> GetAllStudents()
        {
            List<Student> students = new();
            using SqlConnection conn = new(_connectionString);
            string query = "SELECT * FROM Students";

            using SqlCommand cmd = new(query, conn);
            conn.Open();
            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                students.Add(new Student
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString(),
                    Age = (int)reader["Age"],
                    Email = reader["Email"].ToString()
                });
            }
            return students;
        }

        public void InsertStudent(Student student)
        {
            using SqlConnection conn = new(_connectionString);
            string query = "INSERT INTO Students (Name, Age, Email) VALUES (@Name, @Age, @Email)";
            using SqlCommand cmd = new(query, conn);

            cmd.Parameters.AddWithValue("@Name", student.Name);
            cmd.Parameters.AddWithValue("@Age", student.Age);
            cmd.Parameters.AddWithValue("@Email", student.Email);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public void UpdateStudent(Student student)
        {
            using SqlConnection conn = new(_connectionString);
            string query = "UPDATE Students SET Name = @Name, Age = @Age, Email = @Email WHERE Id = @Id";
            using SqlCommand cmd = new(query, conn);

            cmd.Parameters.AddWithValue("@Id", student.Id);
            cmd.Parameters.AddWithValue("@Name", student.Name);
            cmd.Parameters.AddWithValue("@Age", student.Age);
            cmd.Parameters.AddWithValue("@Email", student.Email);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public void DeleteStudent(int id)
        {
            using SqlConnection conn = new(_connectionString);
            string query = "DELETE FROM Students WHERE Id = @Id";
            using SqlCommand cmd = new(query, conn);
            cmd.Parameters.AddWithValue("@Id", id);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public Student GetStudentById(int id)
        {
            using SqlConnection conn = new(_connectionString);
            string query = "SELECT * FROM Students WHERE Id = @Id";
            using SqlCommand cmd = new(query, conn);

            cmd.Parameters.AddWithValue("@Id", id);
            conn.Open();
            using SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Student
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString(),
                    Age = (int)reader["Age"],
                    Email = reader["Email"].ToString()
                };
            }
            return null;
        }
    }
}
